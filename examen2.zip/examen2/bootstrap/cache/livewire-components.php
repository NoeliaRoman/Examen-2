<?php return array (
  'empleados-create' => 'App\\Http\\Livewire\\EmpleadosCreate',
  'empleados-delete' => 'App\\Http\\Livewire\\EmpleadosDelete',
  'empleados-edit' => 'App\\Http\\Livewire\\EmpleadosEdit',
  'empleados-index' => 'App\\Http\\Livewire\\EmpleadosIndex',
  'empleados-view' => 'App\\Http\\Livewire\\EmpleadosView',
);