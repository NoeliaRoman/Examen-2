<div class="row">
    <div class="mx-auto col-6">
        <div class="form-group">
            <label>Primer Nombre</label>
            <input wire:model.defer="empleado.primerNombre" type="text" class="form-control">
            @error('empleado.primerNombre') <span class="text-danger">{{ $message }}</span>@enderror
        </div>

        <div class="form-group">
            <label>Segundo Nombre</label>
            <input wire:model.defer="empleado.segundoNombre" type="text" class="form-control">
            @error('empleado.segundoNombre') <span class="text-danger">{{ $message }}</span>@enderror

        </div>


        <div class="form-group">
            <label>Apellido Paterno</label>
            <input wire:model.defer="empleado.apellidoPaterno" type="text" class="form-control">
            @error('empleado.apellidoPaterno') <span class="text-danger">{{ $message }}</span>@enderror

        </div>

        <div class="form-group">
            <label>Apellido Materno</label>
            <input wire:model.defer="empleado.apellidoMaterno" type="text" class="form-control">
            @error('empleado.apellidoMaterno') <span class="text-danger">{{ $message }}</span>@enderror

        </div>

        <div class="form-group">
            <label>Area Trabajo</label>
            <input wire:model.defer="empleado.areaTrabajo" type="text" class="form-control">
            @error('empleado.areaTrabajo') <span class="text-danger">{{ $message }}</span>@enderror

        </div>

        <div class="form-group">
            <label>Codigo Postal</label>
            <input wire:model.defer="empleado.codigoPostal" type="text" class="form-control">
            @error('empleado.codigoPostal') <span class="text-danger">{{ $message }}</span>@enderror

        </div>

        <div class="form-group">
            <label>Correo Electronico</label>
            <input wire:model.defer="empleado.correoElectronico" type="text" class="form-control">
            @error('empleado.correoElectronico') <span class="text-danger">{{ $message }}</span>@enderror

        </div>

        <div class="form-group">
            <label>Curp</label>
            <input wire:model.defer="empleado.curp" type="text" class="form-control">
            @error('empleado.curp') <span class="text-danger">{{ $message }}</span>@enderror

        </div>

        <div class="form-group">
            <label>Estado</label>
            <input wire:model.defer="empleado.estado" type="text" class="form-control">
            @error('empleado.estado') <span class="text-danger">{{ $message }}</span>@enderror

        </div>

        <div class="form-group">
            <label>Facebook</label>
            <input wire:model.defer="empleado.Facebook" type="text" class="form-control">
            @error('empleado.Facebook') <span class="text-danger">{{ $message }}</span>@enderror

        </div>

        <div class="form-group">
            <label>Fecha de Nacimiento</label>
            <input wire:model.defer="empleado.fechaNacimiento" type="text" class="form-control">
            @error('empleado.fechaNacimiento') <span class="text-danger">{{ $message }}</span>@enderror

        </div>

        <div class="form-group">
            <label>Horario de Trabajo</label>
            <input wire:model.defer="empleado.horarioTrabajo" type="text" class="form-control">
            @error('empleado.horarioTrabajo') <span class="text-danger">{{ $message }}</span>@enderror

        </div>

        <div class="form-group">
            <label>Puesto de Trabajo</label>
            <input wire:model.defer="empleado.puestoTrabajo" type="text" class="form-control">
            @error('empleado.puestoTrabajo') <span class="text-danger">{{ $message }}</span>@enderror

        </div>

        <div class="form-group">
            <label>RFC</label>
            <input wire:model.defer="empleado.RFC" type="text" class="form-control">
            @error('empleado.RFC') <span class="text-danger">{{ $message }}</span>@enderror

        </div>

        <div class="form-group">
            <label>Salario</label>
            <input wire:model.defer="empleado.salario" type="text" class="form-control">
            @error('empleado.salario') <span class="text-danger">{{ $message }}</span>@enderror

        </div>

        <div class="form-group">
            <label>Sexo</label>
            <input wire:model.defer="empleado.sexo" type="text" class="form-control">
            @error('empleado.sexo') <span class="text-danger">{{ $message }}</span>@enderror

        </div>

        <div class="form-group">
            <label>Telefono</label>
            <input wire:model.defer="empleado.telefono" type="text" class="form-control">
            @error('empleado.telefono') <span class="text-danger">{{ $message }}</span>@enderror

        </div>


    </div>



</div>
