<div>
    <div class="mx-auto card" style="width: 18rem;">
        <div class="card-body">
        <h5 class="card-title">Desea eliminarlo?<h5>
          <p class="card-text">{{$empleado->primerNombre}}</p>
          <p class="card-text">{{$empleado->apellidoPaterno}}</p>
          <button wire:click="delete" class="btn btn-primary btn-sm">Confirmar</button>
          <a href="{{route('empleados.index')}}" class="btn btn-secondary btn-sm">Cancelar</a>
        </div>
      </div>
</div>
