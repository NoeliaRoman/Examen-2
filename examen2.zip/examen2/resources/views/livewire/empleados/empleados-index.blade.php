<div>

    <div class="float-right mb-2">
        <a href="{{ route('empleados.create') }}" type="button" class="btn-sm btn btn-success"><i
                class="fa fa-plus-circle"></i> Crear nuevo</a>

    </div>

    <table class="table text-center table-striped">
        <thead>
            <tr>
                <th scope="col">ID</th>
                <th scope="col">Nombre</th>
                <th scope="col">Segundo Nombre</th>
                <th scope="col">Apellido Paterno</th>
                <th scope="col">Apellido Materno</th>

                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>

            @foreach ($empleados as $empleado)
                <tr>
                    <th scope="row">{{ $empleado->id }}</th>
                    <td>{{ $empleado->primerNombre }}</td>
                    <td>{{ $empleado->apellidoPaterno }}</td>
                    <td>{{ $empleado->apellidoMaterno }}</td>
                    <td>
                        <a href="{{ route('empleados.view', $empleado) }}" title="Mostrar más" class="btn-sm btn btn-info"><i class="fa fa-eye"></i></button>
                        <a href="{{ route('empleados.edit', $empleado) }}" title="Editar empleado"
                            class="btn-sm btn btn-primary"><i class="fa fa-edit"></i></a>
                        <a href="{{ route('empleados.delete', $empleado) }}" title="Eliminar empleado seleccionado más"
                            class="btn-sm btn btn-danger"><i class="fa fa-trash"></i></a>
                    </td>
                </tr>
            @endforeach


        </tbody>
    </table>
    {{ $empleados->links() }}
</div>
