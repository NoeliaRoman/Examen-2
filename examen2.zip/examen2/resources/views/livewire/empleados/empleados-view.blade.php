<div>
    <div class="card mx-auto" style="width: 18rem;">
        <div class="card-body">
          <p class="card-title">Primer nombre: {{$empleado->primerNombre}}</p>
          <p class="card-text">Segundo nombre: {{$empleado->segundoNombre}}</p>
          <p class="card-text">Primer apellido: {{$empleado->apellidoPaterno}}</p>
          <p class="card-text">Segundo apellido: {{$empleado->apellidoMaterno}}</p>
          <p class="card-text">Area de Trabajo: {{$empleado->areaTrabajo}}</p>
          <p class="card-text">Codigo Postal: {{$empleado->codigoPostal}}</p>
          <p class="card-text">Correo Electronico: {{$empleado->correElectronico}}</p>
          <p class="card-text">Curp: {{$empleado->curp}}</p>
          <p class="card-text">Estado: {{$empleado->estado}}</p>
          <p class="card-text">Facebook: {{$empleado->Facebook}}</p>
          <p class="card-text">Fecha de Nacimiento: {{$empleado->fechaNacimiento}}</p>
          <p class="card-text">Horario de Trabajo: {{$empleado->horarioTrabajo}}</p>
          <p class="card-text">Puesto de Trabajo: {{$empleado->puestoTrabajo}}</p>
          <p class="card-text">RFC: {{$empleado->RFC}}</p>
          <p class="card-text">Salario: {{$empleado->salario}}</p>
          <p class="card-text">Sexo: {{$empleado->sexo}}</p>
          <p class="card-text">Telefono: {{$empleado->telefono}}</p>
          <a href="{{route('empleados.index')}}" class="btn btn-secondary btn-sm">Regresar</a>
        </div>
      </div>
</div>
