<?php

use App\Http\Controllers\EmpleadoController;
use App\Http\Livewire\EmpleadosCreate;
use App\Http\Livewire\EmpleadosDelete;
use App\Http\Livewire\EmpleadosEdit;
use App\Http\Livewire\EmpleadosIndex;
use App\Http\Livewire\EmpleadosView;
use App\Models\empleado;
use Illuminate\Support\Facades\Route;


Route::get('/empleados', EmpleadosIndex::class)->name('empleados.index');
Route::get('/empleados/create', EmpleadosCreate::class)->name('empleados.create');
Route::get('/empleados/{empleado}/delete', EmpleadosDelete::class)->name('empleados.delete');
Route::get('/empleados/{empleado}/edit', EmpleadosEdit::class)->name('empleados.edit');
Route::get('/empleados/{empleado}/view', EmpleadosView::class)->name('empleados.view');
