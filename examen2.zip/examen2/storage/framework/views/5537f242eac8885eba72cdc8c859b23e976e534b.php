<div>
    <div class="card mx-auto" style="width: 18rem;">
        <div class="card-body">
          <p class="card-title">Primer nombre: <?php echo e($empleado->primerNombre); ?></p>
          <p class="card-text">Segundo nombre: <?php echo e($empleado->segundoNombre); ?></p>
          <p class="card-text">Primer apellido: <?php echo e($empleado->apellidoPaterno); ?></p>
          <p class="card-text">Segundo apellido: <?php echo e($empleado->apellidoMaterno); ?></p>
          <p class="card-text">Area de Trabajo: <?php echo e($empleado->areaTrabajo); ?></p>
          <p class="card-text">Codigo Postal: <?php echo e($empleado->codigoPostal); ?></p>
          <p class="card-text">Correo Electronico: <?php echo e($empleado->correElectronico); ?></p>
          <p class="card-text">Curp: <?php echo e($empleado->curp); ?></p>
          <p class="card-text">Estado: <?php echo e($empleado->estado); ?></p>
          <p class="card-text">Facebook: <?php echo e($empleado->Facebook); ?></p>
          <p class="card-text">Fecha de Nacimiento: <?php echo e($empleado->fechaNacimiento); ?></p>
          <p class="card-text">Horario de Trabajo: <?php echo e($empleado->horarioTrabajo); ?></p>
          <p class="card-text">Puesto de Trabajo: <?php echo e($empleado->puestoTrabajo); ?></p>
          <p class="card-text">RFC: <?php echo e($empleado->RFC); ?></p>
          <p class="card-text">Salario: <?php echo e($empleado->salario); ?></p>
          <p class="card-text">Sexo: <?php echo e($empleado->sexo); ?></p>
          <p class="card-text">Telefono: <?php echo e($empleado->telefono); ?></p>
          <a href="<?php echo e(route('empleados.index')); ?>" class="btn btn-secondary btn-sm">Regresar</a>
        </div>
      </div>
</div>
<?php /**PATH C:\Users\Noeli\Documents\ExamenParcial2\examen2\resources\views/livewire/empleados/empleados-view.blade.php ENDPATH**/ ?>