<div>

    <div class="float-right mb-2">
        <a href="<?php echo e(route('empleados.create')); ?>" type="button" class="btn-sm btn btn-success"><i
                class="fa fa-plus-circle"></i> Crear nuevo</a>

    </div>

    <table class="table text-center table-striped">
        <thead>
            <tr>
                <th scope="col">ID</th>
                <th scope="col">Nombre</th>
                <th scope="col">Segundo Nombre</th>
                <th scope="col">Apellido Paterno</th>
                <th scope="col">Apellido Materno</th>

                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>

            <?php $__currentLoopData = $empleados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empleado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($empleado->id); ?></th>
                    <td><?php echo e($empleado->primerNombre); ?></td>
                    <td><?php echo e($empleado->apellidoPaterno); ?></td>
                    <td><?php echo e($empleado->apellidoMaterno); ?></td>
                    <td>
                        <a href="<?php echo e(route('empleados.view', $empleado)); ?>" title="Mostrar más" class="btn-sm btn btn-info"><i class="fa fa-eye"></i></button>
                        <a href="<?php echo e(route('empleados.edit', $empleado)); ?>" title="Editar empleado"
                            class="btn-sm btn btn-primary"><i class="fa fa-edit"></i></a>
                        <a href="<?php echo e(route('empleados.delete', $empleado)); ?>" title="Eliminar empleado seleccionado más"
                            class="btn-sm btn btn-danger"><i class="fa fa-trash"></i></a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        </tbody>
    </table>
    <?php echo e($empleados->links()); ?>

</div>
<?php /**PATH C:\Users\Noeli\Documents\ExamenParcial2\examen2\resources\views/livewire/empleados/empleados-index.blade.php ENDPATH**/ ?>