<div>
    <div class= "float-right">
        <button type-"button" class="btn btn-success">Guardar</button>
    </div>
<table class="table">
    <thead>
      <tr>
        <th scope="col">#</th>
        <th scope="col">primerNombre</th>
        <th scope="col">apellidoPaterno</th>
        <th scope="col">puestoTrabajo</th>
      </tr>
    </thead>
    <tbody>

        <?php $__currentLoopData = $empleados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empleado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <th scope="row"><?php echo e($empleado->id); ?></th>
        <td><?php echo e($empleado->primerNombre); ?></td>
        <td><?php echo e($empleado->apellidoPaterno); ?></td>
        <td><?php echo e($emplado->puestoTrabajo); ?></td>
      </tr>

    </tbody>
  </table>

  <?php echo e($empleados->links()); ?>


</div>
<?php /**PATH C:\Users\Noeli\Documents\ExamenParcial2\examen2\resources\views/empleados/index.blade.php ENDPATH**/ ?>