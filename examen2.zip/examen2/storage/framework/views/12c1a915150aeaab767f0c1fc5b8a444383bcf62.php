<div>
    <form wire:submit.prevent="editar">
        <div class="card">
            <div class="card-header">
                Modificar empleado
            </div>
            <div class="card-body">
                <?php echo $__env->make('livewire.empleados.formulario', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div class="card-footer text-muted">
                <button class="btn btn-primary btn-sm"><i class="fa fa-iedit"></i> Modificar</button>
                <a href="<?php echo e(route('empleados.index')); ?>" class="btn btn-secondary btn-sm">Regresar</a>
            </div>
        </div>
    </form>

</div>
<?php /**PATH C:\Users\Noeli\Documents\ExamenParcial2\examen2\resources\views/livewire/empleados/empleados-edit.blade.php ENDPATH**/ ?>