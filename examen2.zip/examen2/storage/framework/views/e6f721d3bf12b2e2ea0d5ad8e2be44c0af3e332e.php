<div>
    <form wire:submit.prevent="crear">
        <div class="card">
            <div class="card-header">
                Crear empleado
            </div>
            <div class="card-body">
                <?php echo $__env->make('livewire.empleados.formulario', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div class="card-footer text-muted">
                <button class="btn btn-success btn-sm"><i class="fa fa-save"></i> Guardar</button>
                <a href="<?php echo e(route('empleados.index')); ?>" class="btn btn-secondary btn-sm">Regresar</a>
            </div>
        </div>
    </form>

</div>
<?php /**PATH C:\Users\Noeli\Documents\ExamenParcial2\examen2\resources\views/livewire/empleados/empleados-create.blade.php ENDPATH**/ ?>