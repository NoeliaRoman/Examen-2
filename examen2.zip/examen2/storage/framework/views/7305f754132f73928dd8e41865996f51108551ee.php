<nav class="navbar navbar-light bg-light">
    <div class="container-fluid">
      <a class="navbar-brand" href="#">
        <img src="/docs/5.1/assets/brand/bootstrap-logo.svg" alt="" width="30" height="24" class="d-inline-block align-text-top">
        Bootstrap
      </a>
    </div>
    <div class="container">
        <?php echo $__env->yieldContent('seccion'); ?>
  </nav>
<?php /**PATH C:\Users\Noeli\Documents\ExamenParcial2\examen2\resources\views/layouts/plantilla.blade.php ENDPATH**/ ?>