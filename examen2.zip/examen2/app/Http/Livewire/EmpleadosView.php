<?php

namespace App\Http\Livewire;

use App\Models\empleado;
use Livewire\Component;

class EmpleadosView extends Component
{
    public empleado $empleado;
    public function render()
    {
        return view('livewire.empleados.empleados-view');
    }
}
