<?php

namespace App\Http\Livewire;

use Livewire\Component;
class Rulesempleados
{

    public static function Reglas()
    {
        return
            [
                'empleado.primerNombre' => 'required|string',
                'empleado.segundoNombre' => 'nullable|string',
                'empleado.apellidoPaterno' => 'required|string',
                'empleado.apellidoMaterno' => 'nullable|string',
                'empleado.areaTrabajo'=>'required|string',
                'empleado.codigoPostal'=>'required|integer',
                'empleado.correoElectronico'=>'required|string',
                'empleado.curp'=>'required|string',
                'empleado.estado'=>'required|string',
                'empleado.Facebook'=> 'nullable|string',
                'empleado.fechaNacimiento'=>'required|string',
                'empleado.horarioTrabajo'=>'nullable|string',
                'empleado.puestoTrabajo'=>'required|string',
                'empleado.RFC'=>'required|string',
                'empleado.salario'=>'required|integer',
                'empleado.sexo'=>'nullable|string',
                'empleado.telefono'=>'required|integer',

            ];
    }
}
