<?php

namespace App\Http\Livewire;

use App\Models\empleado;
use Livewire\Component;

class EmpleadosDelete extends Component
{
    public empleado $empleado;
    public function render()
    {
        return view('livewire.empleados.empleados-delete');
    }

    public function delete()
    {
        $this->empleado->delete();
        return redirect(route('empleados.index'));
    }
}
