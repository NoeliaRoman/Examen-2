<?php

namespace App\Http\Livewire;

use App\Http\Livewire\empleadoss\Rulesempleados;
use App\Http\Livewire\Rulesempleados as LivewireRulesempleados;
use App\Models\empleado;
use Livewire\Component;

class EmpleadosEdit extends Component
{
    public empleado $empleado;
    public function render()
    {
        return view('livewire.empleados.empleados-edit');
    }
    public function editar()
    {
        $this->validate();
        $this->empleado->save();
        return redirect(route('empleados.index'));
    }
    protected function rules()
    {
        return LivewireRulesempleados::Reglas();
    }
}
