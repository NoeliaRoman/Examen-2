<?php

namespace App\Http\Livewire;

use Livewire\Component;
use App\Models\empleado;

class EmpleadosIndex extends Component
{
    public function render()
    {
        $empleados = empleado::paginate(5);
        return view('livewire.empleados.empleados-index', compact('empleados'));
    }
}
