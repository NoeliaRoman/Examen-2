<?php

namespace App\Http\Livewire;

use App\Http\Livewire\empleadoss\Rulesempleados;
use App\Http\Livewire\Rulesempleados as LivewireRulesempleados;
use App\Models\empleado;
use Livewire\Component;

class EmpleadosCreate extends Component
{
    public empleado $empleado;
    public function mount()
    {
        $this->empleado = new empleado();
    }

    public function render()
    {
        return view('livewire.empleados.empleados-create');
    }

    public function crear()
    {
        $this->validate();
        $this->empleado->save();
        return redirect(route('empleados.index'));
    }

    protected function rules()
    {
        return LivewireRulesempleados::Reglas();
    }
}
